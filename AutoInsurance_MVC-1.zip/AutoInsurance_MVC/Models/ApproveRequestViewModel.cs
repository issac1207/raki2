﻿using System.ComponentModel.DataAnnotations;

namespace AutoInsurance_MVC.Models
{
    public class ApproveRequestViewModel
    {
       
        public string status { get; set; }
    }
}
