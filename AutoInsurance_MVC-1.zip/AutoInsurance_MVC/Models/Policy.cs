﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_MVC.Models
{
    public class Policy
    {
        
        public int PolicyId { get; set; }
        public int PolicyNumber { get; set;}
        public int PremiumAmount { get; set; }
       
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        
        public int vehicleId { get; set; }
       
    }
}
