﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_MVC.Models

{

    public class RejectedClaimReport

    {

        public int ReportId { get; set; }
        [Required]

        public int ClaimId { get; set; }
        [Required]

        public DateTime ReportDate { get; set; }
        [Required]

        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public ulong Contact { get; set; }

    }

}

