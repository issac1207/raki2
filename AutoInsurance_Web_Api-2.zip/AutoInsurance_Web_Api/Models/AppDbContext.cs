﻿using System.Collections.Generic;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;



namespace AutoInsurance_Web_Api.Models

{

    public class AppDbContext : DbContext

    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<ApprovedClaimReport> ApprovedClaimReport { get; set; }

        public virtual DbSet<RejectedClaimReport> RejectedClaimReport { get; set; }
        public virtual DbSet<Claim> Claim { get; set; }
        public virtual DbSet<VehicleDetails> VehicleDetails { get; set; }
        public virtual DbSet<Policy> Policy { get; set; }


    }

}

