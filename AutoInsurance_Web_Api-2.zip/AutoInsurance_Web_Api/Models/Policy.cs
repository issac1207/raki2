﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_Web_Api.Models
{
    public class Policy
    {
        [Key]
        public int PolicyId { get; set; }
        public int PolicyNumber { get; set;}
        public int PremiumAmount { get; set; }
       
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [ForeignKey("VehicleDetails")]
        public int vehicleId { get; set; }
       public virtual VehicleDetails VehicleDetails { get; set; }
    }
}
