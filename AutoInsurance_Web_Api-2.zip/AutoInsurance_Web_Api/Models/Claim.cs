﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_Web_Api.Models

{

    public class Claim

    {

        [Key]
        public int ClaimId { get; set; }
        [ForeignKey("VechicleDetails")]
        public int VehicleId { get; set; }//
        
        public DateTime ClaimDate { get; set; }
        public float ClaimAmount { get; set; }
        public string NatureOfClaim { get; set; }
        public string Status { get; set; }
        public virtual VehicleDetails VechicleDetails { get; set; }
        

    }

}

