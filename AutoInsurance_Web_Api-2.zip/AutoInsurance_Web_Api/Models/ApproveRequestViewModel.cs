﻿namespace AutoInsurance_Web_Api.Models
{
    public class ApproveRequestViewModel
    {
        public string status { get; set; }
    }
}
