﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_Web_Api.Models
{
    public class VehicleDetails
    {
        [Key]
        public int VehicleId { get; set; }
        [ForeignKey("Customers")]
        public int CustomerId { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int Price { get; set; }
        public virtual User Customers { get; set; }
       

    }
}