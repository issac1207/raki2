﻿namespace AutoInsurance_Web_Api.Models

{

    public class RequestViewModel

    {

        public string Pending { get; set; }

    }

}