﻿using AutoInsurance_Web_Api.Models;



using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;

namespace AutoInsurance_Web_Api.Controllers

{

    [Route("[controller]")]

    [ApiController]

    public class AdminController : ControllerBase

    {

        AppDbContext db = null;

        public AdminController(AppDbContext context)

        {

            this.db = context;

        }

        [HttpPost]

        [Route("AdminLogin")]

        public IActionResult AdminLogin([FromBody] AdminLogin aLog)

        {

            if (aLog.UserName == null || aLog.Password == null)

            {

                return BadRequest();

            }

            if (aLog.UserName == "rakesh@gmail.com" && aLog.Password == "Rakesh@123")

            {

                return Ok("Admin Login successfull !!");

            }

            return BadRequest("Admin with provided details doesn't exist!!");

        }

        [HttpGet]

        [Route("ClaimList")]

        public IActionResult GetClaimList()

        {

            var query = (from a in db.Claim

                         where a.Status == "Pending"

                         select a).ToList();

            return Ok(query);

        }

        [HttpGet]

        [Route("rakesh/{ClaimId}/{status}")]

        public IActionResult ModifyBMDetails(int ClaimId, string status)

        {

            var claim = db.Claim.Find(ClaimId);

            if (claim == null)

            {

                return Ok("claim id is not present");

            }

            claim.Status = status;

            db.Update(claim);

            db.SaveChanges();

            ApprovedClaimReport a = new ApprovedClaimReport();

            RejectedClaimReport b = new RejectedClaimReport();

            if (status == "Approved")

            {

                a.ClaimId = claim.ClaimId;

                a.ReportDate = DateTime.Now;

                var q = db.VehicleDetails.Find(claim.VehicleId);

                int d = q.CustomerId;

                a.UserName = (from user in db.Users

                              where user.UserId == d

                              select user.FirstName).SingleOrDefault();

                a.Email = (from user in db.Users

                           where user.UserId == d

                           select user.Email).SingleOrDefault();

                a.Contact = (from user in db.Users

                             where user.UserId == d

                             select user.Contact).SingleOrDefault();

                db.ApprovedClaimReport.Add(a);

                db.SaveChanges();

            }

            else if (status == "Rejected")

            {

                b.ClaimId = claim.ClaimId;

                b.ReportDate = DateTime.Now;

                var q = db.VehicleDetails.Find(claim.VehicleId);

                int d = q.CustomerId;

                b.UserName = (from user in db.Users

                              where user.UserId == d

                              select user.FirstName).SingleOrDefault();

                b.Email = (from user in db.Users

                           where user.UserId == d

                           select user.Email).SingleOrDefault();

                b.Contact = (from user in db.Users

                             where user.UserId == d

                             select user.Contact).SingleOrDefault();

                db.RejectedClaimReport.Add(b);

                db.SaveChanges();

            }

            return Ok("Updated..");

        }

        [HttpGet]

        [Route("ApprovedClaimReport")]

        public IActionResult GetApprovedClaimReportList()

        {

            var query = db.ApprovedClaimReport.ToList();

            foreach (ApprovedClaimReport a in query)

            {

                int z = a.ClaimId;

                var quer = (from l in db.Claim

                            where l.ClaimId == z

                            select l).SingleOrDefault();

                if (quer.Status != "Approved")

                {

                    db.ApprovedClaimReport.Remove(a);

                    db.SaveChanges();

                }

            }

            return Ok(db.ApprovedClaimReport.ToList());

        }

        [HttpGet]

        [Route("RejectedClaimReport")]

        public IActionResult GetRejectedClaimReportList()

        {

            var query = db.RejectedClaimReport.ToList();

            foreach (RejectedClaimReport a in query)

            {

                int z = a.ClaimId;

                var quer = (from l in db.Claim

                            where l.ClaimId == z

                            select l).SingleOrDefault();

                if (quer.Status != "Rejected")

                {

                    db.RejectedClaimReport.Remove(a);

                    db.SaveChanges();

                }

            }

            return Ok(db.RejectedClaimReport.ToList());

        }

        [HttpGet]

        [Route("ClaimById/{claimId}")]

        public IActionResult ApproveOrRejectScreen(int claimId)

        {

            var query = db.Claim.Find(claimId);

            if (query == null)

            {

                return Ok("claim id is not present");

            }

            string s = query.Status;

            if (s == "Approved")

            {

                return Ok("Approved");

            }

            else if (s == "Rejected")

            {

                return Ok("Rejected");

            }

            else

            {

                return Ok("Pending");

            }

        }

        [HttpGet]

        [Route("{VehicleId}")]

        public IActionResult VehicleDetails(int VehicleId)

        {

            var query = db.VehicleDetails.Find(VehicleId);

            if (query == null)

            {

                return Ok("Not Found");

            }

            return Ok(query);

        }

        [HttpGet]

        [Route("CustomerID/{id}")]

        public IActionResult customerDetails(int id)

        {

            var query = db.Users.Find(id);

            if (query == null)

            {

                return Ok("Not Found");

            }

            return Ok(query);

        }

        //[HttpPost]

        //[Route("ToApprove/{ClaimId}")]

        //public IActionResult Approve(int ClaimId)

        //{

        // string status = "Approved";

        // var claim = db.Claim.Find(ClaimId);

        // if (claim == null)

        // {

        // return Ok("claim id is not present");

        // }

        // claim.Status = status;

        // db.Update(claim);

        // db.SaveChanges();

        // ApprovedClaimReport a = new ApprovedClaimReport();

        // a.ClaimId = claim.ClaimId;

        // a.ReportDate = DateTime.Now;

        // var q = db.VehicleDetails.Find(claim.VehicleId);

        // int d = q.CustomerId;

        // a.UserName = (from user in db.Users

        // where user.UserId == d

        // select user.FirstName).SingleOrDefault();

        // a.Email = (from user in db.Users

        // where user.UserId == d

        // select user.Email).SingleOrDefault();

        // a.Contact = (from user in db.Users

        // where user.UserId == d

        // select user.Contact).SingleOrDefault();

        // db.ApprovedClaimReport.Add(a);

        // db.SaveChanges();

        // return Ok("Updated..");

        //}

        //[HttpPost]

        //[Route("ToReject/{ClaimId}")]

        //public IActionResult Reject(int ClaimId)

        //{

        // string status = "Rejected";

        // var claim = db.Claim.Find(ClaimId);

        // if (claim == null)

        // {

        // return Ok("claim id is not present");

        // }

        // claim.Status = status;

        // db.Update(claim);

        // db.SaveChanges();

        // RejectedClaimReport a = new RejectedClaimReport();

        // a.ClaimId = claim.ClaimId;

        // a.ReportDate = DateTime.Now;

        // var q = db.VehicleDetails.Find(claim.VehicleId);

        // int d = q.CustomerId;

        // a.UserName = (from user in db.Users

        // where user.UserId == d

        // select user.FirstName).SingleOrDefault();

        // a.Email = (from user in db.Users

        // where user.UserId == d

        // select user.Email).SingleOrDefault();

        // a.Contact = (from user in db.Users

        // where user.UserId == d

        // select user.Contact).SingleOrDefault();

        // db.RejectedClaimReport.Add(a);

        // db.SaveChanges();

        // return Ok("Updated..");

        //}

        [HttpPut]

        [Route("ApproveOrReject/{id}")]

        public IActionResult ApproveOrReject([FromQuery] ApproveRequestViewModel ARVM, int id)

        {

            if (id == null)

            {

                return BadRequest();

            }

            var claim = db.Claim.Find(id);

            if (claim == null)

            {

                return Ok("There is No claim with this Id");

            }

            else

            {

                claim.Status = ARVM.status;

                db.Claim.Update(claim);

                db.SaveChanges();

                if (claim.Status == "Approved")

                {

                    ApprovedClaimReport a = new ApprovedClaimReport();

                    a.ClaimId = claim.ClaimId;

                    a.ReportDate = DateTime.Now;

                    var q = db.VehicleDetails.Find(claim.VehicleId);

                    int d = q.CustomerId;

                    a.UserName = (from user in db.Users

                                  where user.UserId == d

                                  select user.FirstName).SingleOrDefault();

                    a.Email = (from user in db.Users

                               where user.UserId == d

                               select user.Email).SingleOrDefault();

                    a.Contact = (from user in db.Users

                                 where user.UserId == d

                                 select user.Contact).SingleOrDefault();

                    db.ApprovedClaimReport.Add(a);

                    db.SaveChanges();

                }

                else if (claim.Status == "Rejected")

                {

                    RejectedClaimReport a = new RejectedClaimReport();

                    a.ClaimId = claim.ClaimId;

                    a.ReportDate = DateTime.Now;

                    var q = db.VehicleDetails.Find(claim.VehicleId);

                    int d = q.CustomerId;

                    a.UserName = (from user in db.Users

                                  where user.UserId == d

                                  select user.FirstName).SingleOrDefault();

                    a.Email = (from user in db.Users

                               where user.UserId == d

                               select user.Email).SingleOrDefault();

                    a.Contact = (from user in db.Users

                                 where user.UserId == d

                                 select user.Contact).SingleOrDefault();

                    db.RejectedClaimReport.Add(a);

                    db.SaveChanges();

                }

                return Ok("Updated.....");

            }

            return BadRequest("Invalid Customer Details...");

        }

        [HttpGet]

        [Route("ToCheckAppOrRejUserDetails/{claimid}")]

        public IActionResult GetCustomerDetails(int claimid)

        {

            search s = new search();

            var query = db.Claim.Find(claimid);
            if(query == null) {
                return Ok("claim Id is not present");
            }
            int vehicleid = query.VehicleId;

            var query1 = (from v in db.VehicleDetails

                          where v.VehicleId == vehicleid

                          select v).SingleOrDefault();

            //var query2 = (from v in db.VehicleDetails select v).SingleOrDefault();

            int m = query1.CustomerId;

            var query4 = (from u in db.Users where u.UserId == m select u).SingleOrDefault();

            s.status = query.Status;

            s.UserId = query4.UserId;

            s.Email = query4.Email;

            s.Contact = query4.Contact;

            s.FirstName = query4.FirstName;

            s.LastName = query4.LastName;

            s.Address = query4.Address;

            if (query4 == null)

            {

                return Ok("user is not present");

            }

            return Ok(s);

        }
        [HttpGet]
        [Route("PolicyId/{PolicyId}")]
        public IActionResult PolicyTable(int PolicyId)
        {
            var query=(from u in db.Policy where u.vehicleId == PolicyId select u).SingleOrDefault();
            if(query == null) {
                return Ok("Not Found");
            }
            return Ok(query);
        }
    }
}

